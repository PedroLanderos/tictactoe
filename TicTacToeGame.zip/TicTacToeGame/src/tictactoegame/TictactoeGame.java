/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Main.java to edit this template
 */
package tictactoegame;

/**
 *
 * @author lande
 */
public class TictactoeGame {
    
    
    public static void main(String[] args) {
        //MainMenu mainmenu = new MainMenu();
        //mainmenu.setVisible(true);
        
        PantallaPrincipal pantalla = new PantallaPrincipal();
        pantalla.setVisible(true);
    }
    
}
